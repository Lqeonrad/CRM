package com.icss.crm.settings.service;

import com.icss.crm.settings.domain.User;
import com.icss.crm.workbench.domain.Activity;

import java.util.List;
import java.util.Map;

/**
 * @author Professor-Cheng
 * @create 2025-06-27 18:36
 */
public interface UserService {
    User queryUserByLoginActAndPwd(Map<String,Object> map);

    List<User> queryAllUsers();

}
