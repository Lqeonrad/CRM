package com.icss.crm.commons.domain;

import java.util.UUID;

/**
 * @author Professor-Cheng
 * @create 2025-06-28 18:38
 */
public class UUIDUtils {
    /**
     * 回去uuid的值
     * @return
     */
    public static String getUUID(){
        return UUID.randomUUID().toString().replaceAll("-","");
    }
}