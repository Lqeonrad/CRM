package com.icss.crm.workbench.service;

import com.icss.crm.workbench.domain.Clue;

import java.util.List;
import java.util.Map;

public interface ClueService {
    List<Clue> getClueList();
    Clue selectClueById(String id);

    int saveCreateClue(Clue clue);
    int deleteClueByIds(String[] ids);

    int saveEditClue(Clue clue);

    List<Clue> queryClueByConditionForPage(Map<String, Object> map);
    int queryCountOfClueByCondition(Map<String, Object> map);

    }




