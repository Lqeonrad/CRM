package com.icss.crm.workbench.web.controller;

import com.icss.crm.commons.contants.Constants;
import com.icss.crm.commons.dateUtils.DateUtils;
import com.icss.crm.commons.domain.ReturnObject;
import com.icss.crm.commons.domain.UUIDUtils;
import com.icss.crm.settings.domain.User;
import com.icss.crm.settings.service.UserService;
import com.icss.crm.workbench.domain.Clue;
import com.icss.crm.workbench.service.ClueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/workbench/clue")
public class ClueController {

    @Autowired
    private UserService userService;

    @Autowired
    private ClueService clueService; // 记得有对应的 ServiceImpl 实现类

    @RequestMapping("/index.do")
    public String index(HttpServletRequest request) {
        // 仍然保留用户信息，用于前端“所有者”下拉框等
        List<User> userList = userService.queryAllUsers();
        request.setAttribute("userList", userList);

        return "workbench/clue/index";
    }

    @RequestMapping("/detail.do")
    public String detail(HttpServletRequest request, String id) {
        Clue clue = clueService.selectClueById(id); // 你应在 ClueService 中声明并实现这个方法
        request.setAttribute("clue", clue);
        return "workbench/clue/detail"; // 返回到 detail.jsp 页面
    }
    @RequestMapping("/saveCreateClue.do")
    @ResponseBody
    public Object saveCreateClue(Clue clue, HttpSession session) {
        User user = (User) session.getAttribute(Constants.SESSION_USER);

        // 设置系统字段
        clue.setId(UUIDUtils.getUUID());
        clue.setCreateTime(DateUtils.formateDateTime(new Date()));
        clue.setCreateBy(user.getId());

        ReturnObject returnObject = new ReturnObject();
        try {
            int result = clueService.saveCreateClue(clue);
            if (result > 0) {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_SUCCESS);
            } else {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
                returnObject.setMessage("系统忙，请稍后再试。");
            }
        } catch (Exception e) {
            e.printStackTrace();
            returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
            returnObject.setMessage("系统异常，请联系管理员。");
        }

        return returnObject;
    }

    @RequestMapping("/deleteClueByIds.do")
    @ResponseBody
    public Object deleteClueByIds(String[] id) {
        ReturnObject returnObject = new ReturnObject();
        try {
            int ret = clueService.deleteClueByIds(id);
            if (ret > 0) {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_SUCCESS);
            } else {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
                returnObject.setMessage("删除失败，请稍后重试...");
            }
        } catch (Exception e) {
            e.printStackTrace();
            returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
            returnObject.setMessage("系统异常");
        }
        return returnObject;
    }

    @RequestMapping("/queryClueById.do")
    @ResponseBody
    public Object queryClueById(String id) {
        Clue clue = clueService.selectClueById(id);
        return clue;
    }

    @RequestMapping("/saveEditClue.do")
    @ResponseBody
    public Object saveEditClue(Clue clue, HttpSession session) {
        User user = (User) session.getAttribute(Constants.SESSION_USER);
        clue.setEditTime(DateUtils.formateDateTime(new Date()));
        clue.setEditBy(user.getId());

        ReturnObject returnObject = new ReturnObject();
        try {
            int result = clueService.saveEditClue(clue);
            if (result > 0) {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_SUCCESS);
            } else {
                returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
                returnObject.setMessage("修改失败，请稍后重试。");
            }
        } catch (Exception e) {
            e.printStackTrace();
            returnObject.setCode(Constants.RETURN_OBJECT_CODE_FAIL);
            returnObject.setMessage("系统异常，请联系管理员。");
        }
        return returnObject;
    }

    @RequestMapping("/queryClueByConditionForPage.do")
    @ResponseBody
    public Object queryClueByConditionForPage(String fullname, String company, String phone,
                                              String source, String owner, String mphone, String state,
                                              int pageNo, int pageSize) {
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("fullname", fullname);
        paramMap.put("company", company);
        paramMap.put("phone", phone);
        paramMap.put("source", source);
        paramMap.put("owner", owner);      // 新增
        paramMap.put("mphone", mphone);    // 新增
        paramMap.put("state", state);      // 新增
        paramMap.put("beginNo", (pageNo - 1) * pageSize);
        paramMap.put("pageSize", pageSize);

        List<Clue> clueList = clueService.queryClueByConditionForPage(paramMap);
        int totalRows = clueService.queryCountOfClueByCondition(paramMap);

        Map<String, Object> resultMap = new HashMap<>();
        resultMap.put("clueList", clueList);
        resultMap.put("totalRows", totalRows);
        return resultMap;
    }

}

