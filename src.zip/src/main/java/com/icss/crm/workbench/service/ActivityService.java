package com.icss.crm.workbench.service;

import com.icss.crm.workbench.domain.Activity;

import java.util.List;
import java.util.Map;

/**
 * @author Professor-Cheng
 * @create 2025-06-28 18:33
 */
public interface ActivityService {
    int saveCreateActivity(Activity activity);

    List<Activity> queryActivityByConditionForPage(Map<String,Object> map);

    int queryCountOfActivityByCondition(Map<String,Object> map);

    int deleteActivityByIds(String[] ids);

    Activity queryActivityById(String id);

    int saveEditActivity(Activity activity);

    Activity queryActivityForDetailById(String id);

    List<Activity> queryAllActivitys();

    int saveCreateActivityByList(List<Activity> activityList);
}
