package com.icss.crm.workbench.service.impl;

import com.icss.crm.workbench.domain.Activity;
import com.icss.crm.workbench.mapper.ActivityMapper;
import com.icss.crm.workbench.service.ActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

/**
 * @author Professor-Cheng
 * @create 2025-06-28 18:34
 */
@Service("activityService")
public class ActivityServiceImpl implements ActivityService {
    @Autowired
    private ActivityMapper activityMapper;

    public int saveCreateActivity(Activity activity) {
        return activityMapper.insertActivity(activity);
    }

    public List<Activity> queryActivityByConditionForPage(Map<String, Object> map) {
        return activityMapper.selectActivityByConditionForPage(map);
    }

    public int queryCountOfActivityByCondition(Map<String, Object> map) {
        return activityMapper.selectCountOfActivityByCondition(map);
    }

    public int deleteActivityByIds(String[] ids) {
        return activityMapper.deleteActivityByIds(ids);
    }

    public Activity queryActivityById(String id) {
        return activityMapper.selectActivityById(id);
    }

    public int saveEditActivity(Activity activity) {
        return activityMapper.updateActivity(activity);
    }

    public Activity queryActivityForDetailById(String id) {
        return activityMapper.selectActivityForDetailById(id);
    }

    public List<Activity> queryAllActivitys() {
        return activityMapper.selectAllActivities();
    }

    public int saveCreateActivityByList(List<Activity> activityList) {
        return activityMapper.insertActivityByList(activityList);
    }
}
