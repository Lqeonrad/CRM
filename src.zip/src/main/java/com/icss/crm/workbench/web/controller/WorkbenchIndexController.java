package com.icss.crm.workbench.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author Professor-Cheng
 * @create 2025-06-27 18:57
 */
@Controller
public class WorkbenchIndexController {
    @RequestMapping("/workbench/index.do")
    public String index(){
        //跳转到业务主页面
        return "workbench/index";
    }
}
