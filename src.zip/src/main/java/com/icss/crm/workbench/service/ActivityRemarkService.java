package com.icss.crm.workbench.service;

import com.icss.crm.workbench.domain.ActivityRemark;

import java.util.List;

/**
 * @author Professor-Cheng
 * @create 2025-06-29 14:19
 */
public interface ActivityRemarkService {
    List<ActivityRemark> queryActivityRemarkForDetailByActivityId(String activityId);
}
