package com.icss.crm.workbench.service.impl;

import com.icss.crm.workbench.domain.ActivityRemark;
import com.icss.crm.workbench.mapper.ActivityRemarkMapper;
import com.icss.crm.workbench.service.ActivityRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author Professor-Cheng
 * @create 2025-06-29 14:19
 */
@Service("activityRemarkService")
public class ActivityRemarkServiceImpl implements ActivityRemarkService {
    @Autowired
    private ActivityRemarkMapper activityRemarkMapper;
    public List<ActivityRemark> queryActivityRemarkForDetailByActivityId(String activityId) {
        return activityRemarkMapper.selectActivityRemarkForDetailByActivityId(activityId);
    }
}
