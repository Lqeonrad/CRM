/**
 * bs_pagination simple localization - GREEK
 *
 * DO NOT CHANGE this file, as it will be overwritten in next update.
 * To use different values, write and use a similar structure js file.
 *
 */
var rsc_bs_pag = {
    go_to_page_title: 'Μετακίνηση στη σελίδα',
    rows_per_page_title: 'Σειρές ανά σελίδα',
    current_page_label: 'Σελίδα',
    current_page_abbr_label: 'σελ.',
    total_pages_label: 'από',
    total_pages_abbr_label: '/',
    total_rows_label: 'από',
    rows_info_records: 'εγγραφές',
    go_top_text: '&laquo;',
    go_prev_text: '&lsaquo;',
    go_next_text: '&rsaquo;',
    go_last_text: '&raquo;'
};